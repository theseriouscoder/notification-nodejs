               var socket = io.connect('10.0.32.75:3000');
               var senddata=function(id1){
                     var xmlhttp = new XMLHttpRequest();
                       xmlhttp.onreadystatechange = function() {
                         if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                                  myFunction1(xmlhttp,id1);
                         }
                       };
                       xmlhttp.open("GET", "data.xml", true);
                       xmlhttp.send();
               }
               var myFunction1=function(xml,i){
                        var xmlDoc = xml.responseXML; 
                       x = xmlDoc.getElementsByTagName("CUSTOMER");
                        var id=x[i-1].getElementsByTagName("CUSTOMERID")[0].childNodes[0].nodeValue;
                       var name=x[i-1].getElementsByTagName("NAME")[0].childNodes[0].nodeValue;
                       var lvt=x[i-1].getElementsByTagName("LVT")[0].childNodes[0].nodeValue;
                       socket.emit('custdata',{id:id,name:name,lvt:lvt});
               }
                var SuccessObj = function(id1){
                        socket.emit('check1',id1);
                        
                }
                var ErrObj = function(id1){
                         
                        socket.emit('check2',id1);
                }
                var ErrObj1 = function(id1){
                         
                        socket.emit('check3',id1);
                }
                  socket.on('id',function(id1){
                        var xml = new XMLHttpRequest();
                        xml.open("GET", "data.xml", true);
                        xml.send();
                        xml.onreadystatechange = function() {
                            if (xml.readyState == 4 && xml.status == 200) {     
                                   var i,temp;
                                   var xmlDoc = xml.responseXML;
                                   var x = xmlDoc.getElementsByTagName("CUSTOMER");
                                   var p=x.length;
                                    if(id1 >0 && id1<=p){
                                         var div = $("div#block"+id1).length;
                                         if(div>0){
                                                 ErrObj(id1);  
                                         }
                                         else{
                                                 SuccessObj(id1);
                                                 var iDiv = document.createElement('div');
                                                 iDiv.id = 'block'+id1;
                                                 iDiv.className = 'block';
                                                 document.getElementsByTagName('new')[0].appendChild(iDiv);
                                                 var today = new Date();
                                                 var elem=document.createElement("img");
                                                 elem.src = 'images/greendot.png';
                                                 elem.id="imgwait";
                                                 document.getElementById("block"+id1).innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;Customer ID: "+id1 +" @ " + today.getHours()+":"+today.getMinutes()+":"+today.getSeconds()+"&nbsp;";
                                                 document.getElementById("block"+id1).appendChild(elem);
                                        }
                                    }
                                    else{
                                         ErrObj1(id1);
                                    }
                            }
                        }; 
                    });           
                socket.on('logout',function(id1){
                        var today = new Date();
                    document.getElementById("block"+id1).innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;Customer ID: "+id1 +" @ " + today.getHours()+":"+today.getMinutes()+":"+today.getSeconds()+" (Logged Out!)";
                    setTimeout(function() {
                          var div = document.getElementById('block'+id1);
                        if (div){
                                  document.getElementsByTagName('new')[0].removeChild(div);
                        }
                    }, 500);
                });
                socket.on('success',function(id1){
                    var today = new Date();
                    document.getElementById("block"+id1).innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;Customer ID: "+id1 +" @ " + today.getHours()+":"+today.getMinutes()+":"+today.getSeconds()+"&nbsp;";
                    var elem=document.createElement("img");
                    elem.src = 'images/successicon.jpg';
                    elem.id="imgwait";
                    document.getElementById("block"+id1).appendChild(elem);
                  /*setTimeout(function() {
                          var div = document.getElementById('block'+id1);
                        if (div){
                                  document.getElementsByTagName('new')[0].removeChild(div);
                        }
                    }, 14000);*/
                  });
var ServerObj = function(){
             this.send = function(id1){
	              
	              socket.emit('notification',id1);
                  senddata(id1);
                  /*socket.on('success'+id1,function(id1){
                    var today = new Date();
                    document.getElementById("block"+id1).innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;Customer ID: "+id1 +" @ " + today.getHours()+":"+today.getMinutes()+":"+today.getSeconds()+"&nbsp;";
                    var elem=document.createElement("img");
                    elem.src = 'images/successicon.jpg';
                    elem.id="imgwait";
                    document.getElementById("block"+id1).appendChild(elem);
                  /*setTimeout(function() {
                          var div = document.getElementById('block'+id1);
                        if (div){
                                  document.getElementsByTagName('new')[0].removeChild(div);
                        }
                    }, 14000);
                  });*/
                  
                }
            this.myFunction = function(xml,id1) {
                var i,temp;
                var xmlDoc = xml.responseXML;
                var x = xmlDoc.getElementsByTagName("CUSTOMER");
                var p=x.length;
                if(id1 >0 && id1<=p && $("div#block"+id1).length >0){
                    send(id1);
                    $("#success").show();
                    $("#danger").hide();
                    $('#id').val('');
                    setTimeout(function() {
                          $('#success').fadeOut('fast');
                    }, 2000);
                }
                else {
                    $("#danger").show();
                    $("#success").hide();
                    $('#id').val('');
                    setTimeout(function() {
                          $('#danger').fadeOut('fast');
                    }, 2000);
                }
            }
            this.loadXMLDoc = function() {
	              var id1= document.getElementById("id").value;
                  if(id1===''){
                    document.getElementById("danger").innerHTML="Enter ID!";
                    $("#danger").show();
                    $("#success").hide();
                    $('#id').val('');
                    setTimeout(function() {
                          $('#danger').fadeOut('fast');
                    }, 2000);
                  }
                  else{
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.open("GET", "data.xml", true);
                xmlhttp.send();
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {     
                         myFunction(xmlhttp,id1);
                    }
                };
                } 
            }
            return this;
          }();
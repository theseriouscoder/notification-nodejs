$(document).ready(function(){
  
				function getCookie(cname) {
   						 var name = cname + "=";
    					 var ca = document.cookie.split(';');
    					 for(var i = 0; i < ca.length; i++) {
        				 var c = ca[i];
        				while (c.charAt(0) == ' ') {
            					c = c.substring(1);
      						  }
        				if (c.indexOf(name) == 0) {
            					return c.substring(name.length, c.length);
        				}
    					}
    					return "";
				}
				
            	var userid=getCookie("custid");
              $("#log-notification").hide();
              $("#data-notification").hide();
              $("#new1").hide();
              $("#conn").hide();
              $("#danger").hide();
              $('#id').focus();
        //ClientObj.login();
    				if (userid!="") {
       					 var id3=userid;
                var ans=window.confirm("go with user id: " + userid +"?");
                if(ans==true)
                 ClientObj.checksocket(id3);
    				}
				$('#id').keypress(function(e){
                   if(e.keyCode==13)
                        $('#senddat').click();
            	  }); 
        
      });
			var newdat;
			var count=1;
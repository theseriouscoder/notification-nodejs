        var a=false,socket,i=15;
        var id3;
        socket = io.connect('http://localhost:1000');
        var ClientObj = function(){
                this.login=function(){
                        var id2= document.getElementById("id").value;
                        checksocket(id2);
                }
                return this;
        }();
        var NewClientObj = function(){
                this.logout = function(){
                       $("#danger").hide();
                       socket.emit('logout',id3);
                        $("#log-notification").hide();
                        $('#login').show();
                        $('#new1').hide();
                        $('#id').val('');
                       location.reload();
                    }
                return this;
        }();
        var checksocket=function(id1){
                id3=id1;
                socket = io.connect('http://localhost:1000');
                socket.emit('id',id3);
                socket.on('check1'+id3,function(id1){
                   document.cookie="custid="+id1;
                   $("#conn").show();
                   $(window).bind('beforeunload', function(){
                        NewClientObj.logout();
                    });
                   document.getElementById("conndata").innerHTML="Welcome client! Your Id: <strong>" + id1 +"</strong>. <br>You are successfully connected with the server."
                    callsocket(id1);
                });
                socket.on('check2'+id3,function(id1){
                    Errsocket(id1);
                });
                socket.on('check3'+id3,function(id1){
                    Errsocket1(id1);
                    
                });
        }
        var Errsocket =function(id1){
                $("#danger").show();
                document.getElementById("danger").innerHTML="Customer Already logged in from different location!";
                $('#id').val('');
                setTimeout(function() {
                    $('#danger').fadeOut('fast');
                }, 2000);
        }
        var Errsocket1 =function(id1){
                $("#danger").show();
                document.getElementById("danger").innerHTML="Invalid Customer ID!";
                $('#id').val('');
                setTimeout(function() {
                    $('#danger').fadeOut('fast');
                }, 2000);
        }
        var callsocket = function(id1){
  		      	socket.on('notification'+id1, function (data) {
    		    	       $('#new1').hide();
    		    	       newdat=data;    
    		    	       $("#data-notification").show();
    		    	       displayCD(newdat);
  			      });	
			        function displayCD(i) {
                  var id4,name1,lvt1;
                  socket.on('custdata'+i,function(id1){
                    id4=id1.id;
                    name1=id1.name;
                    document.getElementById("data-notification").innerHTML =
                 "ID: " + id1.id + "<br>Name: " + id1.name;
                  });
                 socket.emit('success',id1);
                 /*var myvar= setInterval(function(){
                     myTimer()
                 },1000)*/
                 
			        }
              function myTimer(){
                 i--;
                 if(i>-1){
                    document.getElementById('counter').innerHTML="Session ends in : " + i + " . this page will reload after the session ends!";
                 }
                 else{
                    NewClientObj.logout();
                 }
              }
			        
              $("#log-notification").show();
              $('#login').hide();
              $('#new1').show();

              $('#id').val('');
              return true;
        }
var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var fs=require('fs');
server.listen(1000);

/*app.get('/:id', function (req, res) {
   fs.readFile( 'C:/inetpub/wwwroot/hemant-service/users.json', 'utf8', function (err, data) {
       users = JSON.parse( data );
       var user = users["user" + req.params.id] 
       console.log( user );
       res.end( JSON.stringify(user));
   });
});*/

io.on('connection', function (socket) {
  socket.emit('news', { hello: 'world' });
  socket.on('id',function(id1){//receive message
      console.log('a user connected with id '+id1);
      app.get('/'+id1, function (req, res) {
               fs.readFile( 'C:/inetpub/wwwroot/hemant-service1/users.json', 'utf8', function (err, data) {
                     users = JSON.parse( data );
                     var user = users["user" + id1] 
                     console.log( user );
                     res.end( JSON.stringify(user));
               });
      });
  });
});
$(document).ready(function(){
	         		$("#success").hide();
	         		$("#danger").hide();
              $('#id').focus();
              $('#id').keypress(function(e){
                   if(e.keyCode==13)
                        $('#sendnot').click();
              });
              
	           	});
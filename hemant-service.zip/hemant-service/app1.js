var express =require('express');
var app=express();
var fs=require('fs');
var http = require('http');
var io = require('socket.io')(http);
io.on('connection', function(socket){
  socket.on('id',function(id1){//receive message
      console.log('a user connected with id '+id1);
      app.get('/gsgfs', function (req, res) {
          fs.readFile( __dirname + "/" + "servicedata.json", 'utf8', function (err, data) {
             users = JSON.parse( data );
              var user = users["id" + id1] 
              console.log(user);
              res.end( data );
          });
      })
      
  });
});
app.server = http.createServer(app);
app.server.listen(3000);